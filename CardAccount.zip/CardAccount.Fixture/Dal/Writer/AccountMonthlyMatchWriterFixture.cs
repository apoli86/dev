﻿namespace CardAccount.Fixture.Dal.Writer
{
    public class AccountMonthlyMatchWriterFixture
    {
    }
}