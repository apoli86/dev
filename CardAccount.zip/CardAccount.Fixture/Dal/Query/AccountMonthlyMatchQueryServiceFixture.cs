﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAccount.Fixture.Dal.Query
{

    public class AccountMonthlyMatchQueryServiceFixture
    {
        public void GetAccountMonthlyMatches_AssertFields()
        {
            
        }

        public void GetAccountMonthlyMatches_List()
        {
            
        }
    }
}
