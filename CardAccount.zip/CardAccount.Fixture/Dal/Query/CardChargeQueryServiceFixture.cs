﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAccount.Fixture.Dal.Query
{

    public class CardChargeQueryServiceFixture
    {
        public void GetCardCharges_AssertFields()
        {
            
        }

        public void GetCardCharges_List()
        {
            
        }
    }
}
