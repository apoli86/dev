﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAccount.Fixture.Dal.Query
{

    public class CardAccountQueryServiceFixture
    {
        public void GetCardAccounts_AssertFields()
        {
            
        }

        public void GetCardAccounts_List()
        {
            
        }
    }
}
