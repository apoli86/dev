﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAccount.Fixture.Dal.Query
{

    public class AccountTransactionQueryServiceFixture
    {
        public void GetAccountTransactions_AssertFields()
        {
            
        }

        public void GetAccountTransactions_List()
        {
            
        }
    }
}
