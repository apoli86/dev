﻿using Newtonsoft.Json;
using NUnit.Framework;

namespace CardAccount.Fixture
{
    public static class Extensions
    {
        public static void AreEqualByJson<T>(this Assert assert, T expected, T actual)
        {
            var expectedJson = JsonConvert.SerializeObject(expected);
            var actualJson = JsonConvert.SerializeObject(actual);

            Assert.AreEqual(expectedJson, actualJson);
        }
    }
}