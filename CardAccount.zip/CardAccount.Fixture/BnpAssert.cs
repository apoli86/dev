﻿using Newtonsoft.Json;
using NUnit.Framework;

namespace CardAccount.Fixture
{
    public class BnpAssert : Assert
     {
        public static void AreEqualByJson<T>(T expected, T actual)
        {
            var expectedJson = JsonConvert.SerializeObject(expected);
            var actualJson = JsonConvert.SerializeObject(actual);

            AreEqual(expectedJson, actualJson);
        }
     }
}