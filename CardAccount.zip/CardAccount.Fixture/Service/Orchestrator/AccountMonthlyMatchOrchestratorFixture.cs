﻿namespace CardAccount.Fixture.Service.Persister
{
    public class AccountMonthlyMatchOrchestratorFixture
    {
        // TODO use MOQ and Autofixture
        // TODO do an integration test without mock to test that all the services work together
    }
}
