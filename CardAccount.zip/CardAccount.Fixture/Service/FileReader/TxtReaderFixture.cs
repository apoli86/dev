﻿using System;
using System.Collections.Generic;
using System.Linq;
using CardAccount.Service.Entity.File;
using CardAccount.Service.FileReader.Implementation;
using CardAccount.Service.FileReader.Interface;
using FileHelpers;
using NUnit.Framework;

namespace CardAccount.Fixture.Service.FileReader
{
    [TestFixture]
    class TxtReaderFixture
    {
        private ITxtReader _reader;

        [SetUp]
        public void SetUp()
        {
            _reader = new TxtReader();
        }

        [Test]
        public void ReadFile_AccountTransaction()
        {
            var expected = new List<AccountTransactionFileEntity>
            {
                new AccountTransactionFileEntity
                {
                    AccountNumber = "CC00000123",
                    Date = new DateTime(2017, 11, 27),
                    Amount = 100000m,
                    TransactionType = "CR"
                },
                new AccountTransactionFileEntity
                {
                    AccountNumber = "CC00000123",
                    Date = new DateTime(2017, 11, 30),
                    Amount = 11902m,
                    TransactionType = "DR"
                }
            };

            var actual = _reader.ReadFile<AccountTransactionFileEntity>(TestResources.movimenti_cc);

           BnpAssert.AreEqualByJson(expected, actual);
        }

        [Test]
        public void ReadFile_AccountTransactionNullDate()
        {
            var items = _reader.ReadFile<AccountTransactionFileEntity>(TestResources.movimenti_cc_NoDate);

          Assert.IsNull(items.First().Date);
        }

        [Test]
        public void ReadFile_AccountTransactionWrongDate()
        {
            Assert.Throws<ConvertException>(() => _reader.ReadFile<AccountTransactionFileEntity>(TestResources.movimenti_cc_WrongDate));
        }


        [Test]
        public void ReadFile_CardCharge()
        {
            var expected = new List<CardChargeFileEntity>
            {
                new CardChargeFileEntity
                {
                    Date = new DateTime(2017, 11, 10),
                    Number = "ABC123",
                    Amount = 6.99m
                },
                new CardChargeFileEntity
                {
                    Date = new DateTime(2017, 11, 10),
                    Number = "ABC123",
                    Amount = 22.5m
                }
            };

            var actual = _reader.ReadFile<CardChargeFileEntity>(TestResources.spese_carta);

            BnpAssert.AreEqualByJson(expected, actual);
        }
    }
}
