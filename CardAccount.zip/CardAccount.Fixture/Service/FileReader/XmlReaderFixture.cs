﻿using CardAccount.Service.Entity.File;
using CardAccount.Service.FileReader.Implementation;
using CardAccount.Service.FileReader.Interface;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;

namespace CardAccount.Fixture.Service.FileReader
{
    [TestFixture]
    class XmlReaderFixture
    {
        private IXmlReader _reader;

        [SetUp]
        public void SetUp()
        {
            _reader = new XmlReader();
        }

        [Test]
        public void ReadFile_CardAccount()
        {
            var expected = new List<CardAccountFileEntity>
            {
                new CardAccountFileEntity
                {
                    AccountNumber = "CC00000123",
                    Cards = new List<CardReference>
                    {
                        new CardReference { Number = "ABC123" },
                        new CardReference { Number = "XYZ456" }
                    }
                },
                new CardAccountFileEntity
                {
                    AccountNumber = "CC00000987",
                    Cards = new List<CardReference>
                    {
                        new CardReference { Number = "ABC456" }
                    }
                }
            };

            var e1 = expected[0].GetHashCode();
            var e2 = expected[1].GetHashCode();

            var actual = _reader.ReadFile<CardAccountFileEntity>(TestResources.carte_conti);

            var a1 = actual[0].GetHashCode();
            var a2 = actual[1].GetHashCode();

            Compare(expected, actual);
        

            BnpAssert.AreEqualByJson(expected, actual);
        }

        private void Compare<T>(IList<T> expected, IList<T> actual)
        {
            var type = typeof(T);

            var props = type.GetProperties();
        }


       

    }
}