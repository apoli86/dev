﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAccount.Fixture.Service.Upload
{
    public class UploadServiceFixture
    {
        // TODO use MOQ (Setup, Verify) for the service dependencies 
        // TODO use Autofixture to build setup entities
    }
}
