﻿namespace CardAccount.Fixture.Service.Persister
{
    public class AccountMonthlyMatchPersisterFixture
    {
        // TODO use MOQ and Autofixture
    }
}
