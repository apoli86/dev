﻿namespace CardAccount.Fixture.Service.Persister
{
    public class CardChargePersisterFixture
    {
        // TODO use MOQ nd Autofixture
    }
}
