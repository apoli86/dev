﻿namespace CardAccount.Fixture.Service.Persister
{
    public class AccountTransactionPersisterFixture
    {
        // TODO use MOQ nd Autofixture
    }
}
