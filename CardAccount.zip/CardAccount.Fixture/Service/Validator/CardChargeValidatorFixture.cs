﻿using System;
using System.Collections.Generic;
using CardAccount.Service.Entity.File;
using CardAccount.Service.Validator.Implementation;
using CardAccount.Service.Validator.Interface;
using NUnit.Framework;
using NUnit.Framework.Internal;
using AutoFixture;
using AutoFixture.Dsl;
using System.Linq;

namespace CardAccount.Fixture.Service.Validator
{
    [TestFixture]
    public class CardChargeValidatorFixture
    {
        private ICardChargeValidator _validator;

        [SetUp]
        public void SetUp()
        {
            _validator = new CardChargeValidator();
        }

        [Test]
        public void TestValidation()
        {
            var fixture = new AutoFixture.Fixture();

            var item = fixture
                .Build<CardChargeFileEntity>()
                .Create();

            var items = new List<CardChargeFileEntity> {item};

            var result = _validator.ValidateCardChargeList(items);

            Assert.IsTrue(result.IsValid);
        }

        [Test]
        public void TestRules()
        {
            var fixture = new AutoFixture.Fixture();

            var numberNull = fixture.Build<CardChargeFileEntity>()
                .With(e => e.Number, (string)null).Create();

            var dateNull = fixture.Build<CardChargeFileEntity>()
                .With(e => e.Date, (DateTime?)null).Create();

            var amountNull = fixture.Build<CardChargeFileEntity>()
                .With(e => e.Amount, (decimal?)null).Create();

            var amountZero = fixture.Build<CardChargeFileEntity>()
                .With(e => e.Amount, 0m).Create();

            var items = new List<CardChargeFileEntity>
            {
                numberNull,
                dateNull,
                amountNull,
                amountZero
            };

            var result = _validator.ValidateCardChargeList(items);

            Assert.IsFalse(result.IsValid);

            Assert.IsTrue(result.Errors.Any(e => e.Contains(nameof(CardChargeFileEntity.Number))));

            Assert.IsTrue(result.Errors.Any(e => e.Contains(nameof(CardChargeFileEntity.Date))));

            Assert.IsTrue(result.Errors.Any(e => e.Contains(nameof(CardChargeFileEntity.Amount))));
        }
    }
}
