﻿using System;
using System.Collections.Generic;
using CardAccount.Service.Entity.File;
using NUnit.Framework;
using System.Linq;
using CardAccount.Service.Validator.Implementation;
using CardAccount.Service.Validator.Interface;
using AutoFixture;

namespace CardAccount.Fixture.Service.Validator
{
    public class AccountTransactionValidatorFixture
    {
        private IAccountTransactionValidator _validator;

        [SetUp]
        public void SetUp()
        {
            _validator = new AccountTransactionValidator();
        }

        [Test]
        public void ValidateAccountTransactionList_Success()
        {
            var fixture = new AutoFixture.Fixture();

            var item = fixture
                .Build<AccountTransactionFileEntity>()
                .With(e => e.TransactionType, "CR")
                .Create();

            var items = new List<AccountTransactionFileEntity> { item };

            //SUT
            var result = _validator.ValidateAccountTransactionList(items);

            Assert.IsTrue(result.IsValid);
        }

        [Test]
        public void ValidateAccountTransactionList_InvalidRules()
        {
            var fixture = new AutoFixture.Fixture();

            var numberNull = fixture.Build<AccountTransactionFileEntity>()
                .With(e => e.AccountNumber, (string)null).Create();

            var dateNull = fixture.Build<AccountTransactionFileEntity>()
                .With(e => e.Date, (DateTime?)null).Create();

            var amountNull = fixture.Build<AccountTransactionFileEntity>()
                .With(e => e.Amount, (decimal?)null).Create();

            var amountZero = fixture.Build<AccountTransactionFileEntity>()
                .With(e => e.Amount, 0m).Create();

            var transactionTypeNull = fixture.Build<AccountTransactionFileEntity>()
                .With(e => e.TransactionType, (string) null).Create();

            var transactionTypeWrong = fixture.Build<AccountTransactionFileEntity>()
                .With(e => e.TransactionType, "CCC").Create();

            var items = new List<AccountTransactionFileEntity>
            {
                numberNull,
                dateNull,
                amountNull,
                amountZero,
                transactionTypeNull,
                transactionTypeWrong
            };

            //SUT
            var result = _validator.ValidateAccountTransactionList(items);

            Assert.IsNotNull(result);

            Assert.AreEqual(result.Errors.Count, 6);

            Assert.IsFalse(result.IsValid);

            Assert.That(result.Errors.Count(e => e.Contains(nameof(AccountTransactionFileEntity.AccountNumber))), Is.EqualTo(1));

            Assert.IsTrue(result.Errors.Any(e => e.Contains(nameof(AccountTransactionFileEntity.Date))));

            Assert.IsTrue(result.Errors.Any(e => e.Contains(nameof(AccountTransactionFileEntity.Amount))));

            Assert.IsTrue(result.Errors.Any(e => e.Contains(nameof(AccountTransactionFileEntity.TransactionType))));
        }
    }
}