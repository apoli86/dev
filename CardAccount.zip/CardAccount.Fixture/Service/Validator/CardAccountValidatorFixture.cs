﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using CardAccount.Service.Entity.File;
using CardAccount.Service.Validator.Implementation;
using CardAccount.Service.Validator.Interface;
using NUnit.Framework;
using NUnit.Framework.Internal;
using AutoFixture;

namespace CardAccount.Fixture.Service.Validator
{
    [TestFixture]
    public class CardAccountValidatorFixture
    {
        private ICardAccountValidator _validator;

        [SetUp]
        public void SetUp()
        {
            _validator = new CardAccountValidator();
        }

        [Test]
        public void TestAccountNumberNullOrEmpty()
        {
            var accountNull = BuildItem(x => x.AccountNumber, null);
            var cardsNull = BuildItem(x => x.Cards, null);
            var cardNumberNull = BuildItem();
            cardNumberNull.Cards.First().Number = null;

            var items = new List<CardAccountFileEntity>
            {
                accountNull,
                cardsNull,
                cardNumberNull
            };

            var item = BuildItem(x => x.AccountNumber, "");

            var result = _validator.ValidateCardAccountList(items);

            Assert.IsFalse(result.IsValid);
            Assert.IsTrue(result.Errors.Any(e => e.Contains(nameof(CardAccountFileEntity.AccountNumber))));
        }

        private CardAccountFileEntity BuildItem(Expression<Func<CardAccountFileEntity, object>> expression, object value)
        {
            var fixture = new AutoFixture.Fixture();

            var item = fixture
                .Build<CardAccountFileEntity>()
                .With(expression, value)
                .Create();

            return item;
        }

        private CardAccountFileEntity BuildItem()
        {
            var fixture = new AutoFixture.Fixture();

            var item = fixture
                .Build<CardAccountFileEntity>()
                .Create();

            return item;
        }
    }
}
