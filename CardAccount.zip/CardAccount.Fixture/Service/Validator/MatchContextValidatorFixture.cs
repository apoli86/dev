﻿namespace CardAccount.Fixture.Service.Validator
{
    public class MatchContextValidatorFixture
    {
    }
}
