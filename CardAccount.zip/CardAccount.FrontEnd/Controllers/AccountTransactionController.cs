﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace CardAccount.FrontEnd.Controllers
{
    public class AccountTransactionController : ApiController
    {
        [HttpPost]
        public IHttpActionResult UploadAccountTransactionFile()
        {
            // TODO use UploadService
            return Ok();
        }

        [HttpGet]
        public IHttpActionResult GetAccountTransactions()
        {
            //TODO Use query services return DTO
            return Ok();
        }
    }
}