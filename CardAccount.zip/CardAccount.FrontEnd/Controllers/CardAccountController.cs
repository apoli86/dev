﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace CardAccount.FrontEnd.Controllers
{
    public class CardAccountController : ApiController
    {

    }
}