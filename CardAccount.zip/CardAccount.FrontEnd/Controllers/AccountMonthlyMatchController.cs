﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace CardAccount.FrontEnd.Controllers
{
    public class AccountMonthlyMatchController : ApiController
    {
        [HttpGet]
        public IHttpActionResult GetAccountMonthlyMatches()
        {
            //TODO Use query service with DTO
            return Ok();
        }

        [HttpGet]
        public IHttpActionResult GetAccountTransactions(long accountMonthlyMatchId)
        {
            //TODO Use query service with DTO
            return Ok();
        }

        [HttpGet]
        public IHttpActionResult GetCardCharges(long accountMonthlyMatchId)
        {
            //TODO Use query service with DTO
            return Ok();
        }
    }
}