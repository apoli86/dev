﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAccount.Model
{
    public class AccountTransaction
    {
        public virtual long Id { get; set; }
        public virtual Account Account { get; set; }
        public virtual TransactionType TransactionType { get; set; }
        public virtual DateTime Date { get; set; }
        public virtual decimal Amount { get; set; }
    }
}
