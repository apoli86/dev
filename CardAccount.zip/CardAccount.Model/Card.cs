﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAccount.Model
{
    public class Card
    {
        public long Id { get; set; }
        public string Number { get; set; }
        public long AccountId { get; set; }
    }
}
