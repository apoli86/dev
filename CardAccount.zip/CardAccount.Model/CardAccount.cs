﻿using System.Collections.Generic;

namespace CardAccount.Model
{
    public class CardAccount
    {
        public Account Account { get; set; }
        public List<Card> Cards { get; set; }
    }
}
