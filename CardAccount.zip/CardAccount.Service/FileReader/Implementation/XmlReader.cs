﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using CardAccount.Service.Entity.File;
using CardAccount.Service.FileReader.Interface;

namespace CardAccount.Service.FileReader.Implementation
{
    public class XmlReader : IXmlReader
    {
        public IList<T> ReadFile<T>(byte[] bytes) where T : class, IFileEntity
        {
            if(bytes == null)
                throw new ArgumentNullException(nameof(bytes));

            var serializer = new XmlSerializer(typeof(T));

            var document = LoadDocument(bytes);

            var items = new List<T>();

            foreach (XmlNode node in document.FirstChild.ChildNodes)
            {
                items.Add(DeserializeNode<T>(node, serializer));
            }

            return items;
        }

        private XmlDocument LoadDocument(byte[] bytes)
        {
            try
            {
                var document = new XmlDocument();

                using (var ms = new MemoryStream(bytes))
                {
                    ms.Position = 0;

                    document.Load(ms);
                }

                return document;
            }
            catch (Exception e)
            {
               throw new Exception($"Unable to load document. Reason: {e.Message}", e);
            }
        }

        private T DeserializeNode<T>(XmlNode node, XmlSerializer serializer) where T : class
        {
            try
            {
                using (var reader = new XmlNodeReader(node))
                {
                    var retVal = serializer.Deserialize(reader);

                    return retVal as T;
                }
            }
            catch (Exception e)
            {
                throw new Exception($"Unable to deserialize node. Reason: {e.Message}", e);
            }
        }
    }
}
