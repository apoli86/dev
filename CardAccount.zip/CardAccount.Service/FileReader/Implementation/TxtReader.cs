﻿using System;
using System.Collections.Generic;
using CardAccount.Service.Entity.File;
using CardAccount.Service.FileReader.Interface;
using FileHelpers;

namespace CardAccount.Service.FileReader.Implementation
{
    public class TxtReader : ITxtReader
    {
        public IList<T> ReadFile<T>(byte[] bytes) where T : class, IFileEntity
        {
            try
            {
                var engine = new FileHelperEngine<T>();

                var items = engine.ReadStream(bytes.ToStreamReader());

                return items as IList<T>;
            }
            catch (Exception e)
            {
                throw new Exception($"Unable to read file. Reason: {e.Message}", e);
            }
        }
    }
}