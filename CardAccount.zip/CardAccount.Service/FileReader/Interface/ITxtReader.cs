﻿using System.Collections.Generic;
using CardAccount.Service.Entity;
using CardAccount.Service.Entity.File;

namespace CardAccount.Service.FileReader.Interface
{
    public interface ITxtReader
    {
        IList<T> ReadFile<T>(byte[] bytes) where T : class, IFileEntity;
    }
}
