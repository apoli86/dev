﻿using FileHelpers;
using System.IO;

namespace CardAccount.Service.FileReader
{
    public static class FileReaderExtensions
    {
        public static StreamReader ToStreamReader(this byte[] bytes)
        {
            return new StreamReader(new MemoryStream(bytes));
        }
    }
}