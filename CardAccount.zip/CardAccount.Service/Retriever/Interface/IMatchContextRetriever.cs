﻿using CardAccount.Service.Entity;

namespace CardAccount.Service.Retriever.Interface
{
    public interface IMatchContextRetriever
    {
        MatchContext RetrieverMatchContext(int year, int month);
    }
}
