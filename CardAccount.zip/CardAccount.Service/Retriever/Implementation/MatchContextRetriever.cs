﻿using CardAccount.Service.Entity;
using CardAccount.Service.Retriever.Interface;

namespace CardAccount.Service.Retriever.Implementation
{
    public class MatchContextRetriever : IMatchContextRetriever
    {
        public MatchContext RetrieverMatchContext(int year, int month)
        {
            //TODO return MatchContext with all the data needed for the process, like list of CardCharges, AccountTransaction and MatchStatus
            throw new System.NotImplementedException();
        }
    }
}
