﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CardAccount.Service.Calculator.Interface;
using CardAccount.Service.Entity;

namespace CardAccount.Service.Calculator.Implementation
{
    public class AccountMonthlyMatchCalculator : IAccountMonthlyMatchCalculator
    {
        public IList<AccountMonthlyMatchCalculationResult> CalculateAccountMonthlyMatches(MatchContext matchContext)
        {
            //TODO return a list of dto, one for each account match
            throw new NotImplementedException();
        }
    }
}
