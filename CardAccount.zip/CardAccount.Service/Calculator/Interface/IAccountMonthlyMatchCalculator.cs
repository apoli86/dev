﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CardAccount.Service.Entity;

namespace CardAccount.Service.Calculator.Interface
{
    public interface IAccountMonthlyMatchCalculator
    {
        IList<AccountMonthlyMatchCalculationResult> CalculateAccountMonthlyMatches(MatchContext matchContext);
    }
}
