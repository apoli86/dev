﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CardAccount.Service.Entity.File;
using CardAccount.Service.Persister.Interface;

namespace CardAccount.Service.Persister.Implementation
{
    public class CardChargePersister: ICardChargePersister
    {
        public void PersistCardAccountFileEntities(IList<CardChargeFileEntity> entities)
        {
            if (entities == null || !entities.Any())
                throw new ArgumentNullException(nameof(entities));

            
            // TODO if card not exists throw exception or log error
            // TODO add card charge using writers
            throw new NotImplementedException();
        }
    }
}
