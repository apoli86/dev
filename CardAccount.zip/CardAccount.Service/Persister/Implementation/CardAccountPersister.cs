﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CardAccount.Service.Entity.File;
using CardAccount.Service.Persister.Interface;

namespace CardAccount.Service.Persister.Implementation
{
    public class CardAccountPersister: ICardAccountPersister
    {
        public void PersistCardAccountFileEntities(IList<CardAccountFileEntity> entities)
        {
            // TODO add account if not exists, add card if not exists using writers
            // TODO if card exists and is linked to another account throw exception (or notify with error log)
            throw new NotImplementedException();
        }
    }
}
