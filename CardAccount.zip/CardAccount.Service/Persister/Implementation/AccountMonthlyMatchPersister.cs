﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CardAccount.Service.Entity;
using CardAccount.Service.Entity.File;
using CardAccount.Service.Persister.Interface;

namespace CardAccount.Service.Persister.Implementation
{
    public class AccountMonthlyMatchPersister: IAccountMonthlyMatchPersister
    {
        public void PersistAccountMonthlyMatches (IList<AccountMonthlyMatchCalculationResult> infos)
        {
            // TODO add or updated if already exists account monthly match using writers
            throw new NotImplementedException();
        }
    }
}
