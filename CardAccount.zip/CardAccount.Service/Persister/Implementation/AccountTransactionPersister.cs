﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CardAccount.Service.Entity.File;
using CardAccount.Service.Persister.Interface;

namespace CardAccount.Service.Persister.Implementation
{
    public class AccountTransactionPersister: IAccountTransactionPersister
    {
        public void PersistCardAccountFileEntities(IList<AccountTransactionFileEntity> entities)
        {
            // TODO add account if not exists
            // TODO add account transaction using writers
            throw new NotImplementedException();
        }
    }
}
