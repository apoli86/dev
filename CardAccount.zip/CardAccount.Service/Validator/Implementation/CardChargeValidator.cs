﻿using System.Collections.Generic;
using System.Linq;
using CardAccount.Service.Entity;
using CardAccount.Service.Entity.File;
using CardAccount.Service.Validator.Interface;
using FluentValidation;

namespace CardAccount.Service.Validator.Implementation
{
    public class CardChargeValidator: EntityValidator<CardChargeFileEntity>, ICardChargeValidator
    {
        public CardChargeValidator()
        {
            RuleFor(e => e.Number)
                .NotNull()
                .NotEmpty()
                .WithNullOrEmptyMessage(nameof(CardChargeFileEntity.Number));

            RuleFor(e => e.Date)
                .NotNull()
                .WithNullMessage(nameof(CardChargeFileEntity.Date));

            RuleFor(e => e.Amount)
                .NotNull()
                .WithNullMessage(nameof(CardChargeFileEntity.Amount))
                .GreaterThan(0)
                .WithZeroOrLessMessage(nameof(CardChargeFileEntity.Amount));
        }

        public ValidationResult ValidateCardChargeList(IList<CardChargeFileEntity> entities)
        {
            return ValidateItems(entities);
        }
    }
}
