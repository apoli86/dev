﻿using System.Collections.Generic;
using System.Linq;
using CardAccount.Service.Entity;
using CardAccount.Service.Entity.File;
using CardAccount.Service.Validator.Interface;
using FluentValidation;

namespace CardAccount.Service.Validator.Implementation
{
    public class CardAccountValidator : EntityValidator<CardAccountFileEntity>, ICardAccountValidator
    {
        public CardAccountValidator()
        {
            RuleFor(e => e.AccountNumber)
                .NotNull()
                .WithNullOrEmptyMessage(nameof(CardAccountFileEntity.AccountNumber));

            RuleFor(e => e.Cards)
                .NotNull()
                .NotEmpty()
                .WithNullOrEmptyMessage(nameof(CardAccountFileEntity.Cards));

            RuleForEach(e => e.Cards)
                .Must(m => !string.IsNullOrEmpty(m.CardNumber))
                .WithNullOrEmptyMessage(nameof(CardFileEntity.Number));
        }

        public ValidationResult ValidateCardAccountList(IList<CardAccountFileEntity> entities)
        {
            return ValidateItems(entities);
        }
    }
}
