﻿using System;
using System.Collections.Generic;
using System.Linq;
using CardAccount.Service.Entity;
using CardAccount.Service.Entity.File;
using CardAccount.Service.Validator.Interface;
using FluentValidation;

namespace CardAccount.Service.Validator.Implementation
{
    public class AccountTransactionValidator: EntityValidator<AccountTransactionFileEntity>, IAccountTransactionValidator
    {
        public AccountTransactionValidator()
        {
            RuleFor(e => e.AccountNumber)
                .NotNull()
                .NotEmpty()
                .WithNullOrEmptyMessage(nameof(AccountTransactionFileEntity.AccountNumber));

            RuleFor(e => e.Date)
                .NotNull()
                .WithNullMessage(nameof(AccountTransactionFileEntity.Date));

            RuleFor(e => e.Amount)
                .NotNull()
                .WithNullMessage(nameof(AccountTransactionFileEntity.Amount))
                .GreaterThan(0)
                .WithZeroOrLessMessage(nameof(AccountTransactionFileEntity.Amount));

            RuleFor(e => e.TransactionType)
                .NotNull()
                .WithNullMessage(nameof(AccountTransactionFileEntity.TransactionType));

            RuleFor(e => e.TransactionType)
                .Must(t => t == Consts.TransactionType.CR || 
                           t == Consts.TransactionType.DR)
                .WithMessage($"{nameof(AccountTransactionFileEntity.TransactionType)} must be {Consts.TransactionType.CR} or {Consts.TransactionType.DR}.");
        }

        public ValidationResult ValidateAccountTransactionList(IList<AccountTransactionFileEntity> entities)
        {
            return ValidateItems(entities);
        }
    }
}
