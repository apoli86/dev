﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CardAccount.Service.Entity;
using CardAccount.Service.Entity.File;
using CardAccount.Service.Validator.Interface;

namespace CardAccount.Service.Validator.Implementation
{
    public class MatchContextValidator: IMatchContextValidator
    {
        public ValidationResult ValidateMatchContext(MatchContext matchContext)
        {
            //TODO chek all there are all statuses needed (Match, Unmatch, Error)
            throw new NotImplementedException();
        }
    }
}
