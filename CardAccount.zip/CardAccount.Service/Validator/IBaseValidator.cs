﻿using CardAccount.Service.Entity;
using System.Collections.Generic;

namespace CardAccount.Service.Validator
{
    public interface IBaseValidator<TEntity>
    {
        ValidationResult ValidateAccountTransactionList(IList<TEntity> entities);
    }
}