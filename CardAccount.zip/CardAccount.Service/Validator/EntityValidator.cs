﻿using System.Collections.Generic;
using System.Linq;
using CardAccount.Service.Entity;
using FluentValidation;

namespace CardAccount.Service.Validator
{
    public abstract class EntityValidator<TEntity> : AbstractValidator<TEntity> where TEntity : class
    {
        public ValidationResult ValidateEntity(TEntity entity)
        {
            if (entity == null)
                throw new System.ArgumentNullException(nameof(entity));

            var result = Validate(entity);

         
            return new ValidationResult
            {
                IsValid = result.IsValid,
                Errors = result.Errors.Select(e => $"{e.ErrorMessage}").ToList()
            };
        }

        protected ValidationResult ValidateItems(IList<TEntity> entities)
        {
            var validations = entities.Select(Validate);

            return new ValidationResult
            {
                IsValid = validations.All(v => v.IsValid),
                Errors = validations.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).ToList()
            };
        }

    }
}