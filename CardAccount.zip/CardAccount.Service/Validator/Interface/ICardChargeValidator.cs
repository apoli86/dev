﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CardAccount.Service.Entity;
using CardAccount.Service.Entity.File;

namespace CardAccount.Service.Validator.Interface
{
    public interface ICardChargeValidator
    {
        ValidationResult ValidateCardChargeList(IList<CardChargeFileEntity> entities);
    }
}
