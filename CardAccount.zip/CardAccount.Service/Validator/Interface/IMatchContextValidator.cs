﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CardAccount.Service.Entity;

namespace CardAccount.Service.Validator.Interface
{
    public interface IMatchContextValidator
    {
        ValidationResult ValidateMatchContext(MatchContext matchContext);
    }
}
