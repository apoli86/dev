﻿using FluentValidation;

namespace CardAccount.Service.Validator
{
    public static class ValidatorExtensions
    {
        public static IRuleBuilderOptions<T, TProperty> WithNullOrEmptyMessage<T, TProperty>(
            this IRuleBuilderOptions<T, TProperty> rule, string propName)
        {
            rule.WithMessage($"{propName} cannot be null or empty.");

            return rule;
        }

        public static IRuleBuilderOptions<T, TProperty> WithNullMessage<T, TProperty>(
            this IRuleBuilderOptions<T, TProperty> rule, string propName)
        {
            rule.WithMessage($"{propName} cannot be null.");

            return rule;
        }

        public static IRuleBuilderOptions<T, TProperty> WithZeroOrLessMessage<T, TProperty>(
            this IRuleBuilderOptions<T, TProperty> rule, string propName)
        {
            rule.WithMessage($"{propName} cannot be 0 or less.");

            return rule;
        }

    }
}