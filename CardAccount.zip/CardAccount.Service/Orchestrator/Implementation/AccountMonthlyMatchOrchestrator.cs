﻿using CardAccount.Service.Orchestrator.Interface;

namespace CardAccount.Service.Orchestrator.Implementation
{
    class AccountMonthlyMatchOrchestrator : IAccountMonthlyMatchOrchestrator
    {
        public void ProcessAccountMonthlyMatch(int year, int month)
        {
            //TODO get all the data needed for the process with MatchContextRetriever
            //TODO validate the context with MatchContextValidator
            //TODO calculate the matches for each account with AccountMonthlyMatchCalculator
            //TODO persists the matches with the AccountMonthlyMatchPersister
            throw new System.NotImplementedException();
        }
    }
}
