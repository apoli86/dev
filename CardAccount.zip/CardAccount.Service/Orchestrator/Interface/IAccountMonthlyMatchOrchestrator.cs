﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CardAccount.Service.Orchestrator.Interface
{
    interface IAccountMonthlyMatchOrchestrator
    {
        void ProcessAccountMonthlyMatch(int year, int month);
    }
}
