﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CardAccount.Service.Entity;

namespace CardAccount.Service.Upload.Interface
{
    public interface IUploadService
    {
        UploadResult UploadCardAccountFile(byte[] bytes);
        UploadResult UploadAccountTransactionFile(byte[] bytes);
        UploadResult UploadCardChargeFile(byte[] bytes);
    }
}
