﻿using CardAccount.Service.Entity;
using CardAccount.Service.Entity.File;
using CardAccount.Service.FileReader.Interface;
using CardAccount.Service.Upload.Interface;
using CardAccount.Service.Validator.Interface;

namespace CardAccount.Service.Upload.Implementation
{
    public class UploadService: IUploadService
    {
        private readonly IXmlReader _xmlReader;
        private readonly ITxtReader _txtReader;
        private readonly ICardAccountValidator _cardAccountValidator;
        private readonly IAccountTransactionValidator _accountTransactionValidator;
        private readonly ICardChargeValidator _cardChargeValidator;

        public UploadService(
            IXmlReader xmlReader, 
            ITxtReader txtReader, 
            ICardAccountValidator cardAccountValidator, 
            IAccountTransactionValidator accountTransactionValidator,
            ICardChargeValidator cardChargeValidator)
        {
            _xmlReader = xmlReader;
            _txtReader = txtReader;
            _cardAccountValidator = cardAccountValidator;
            _accountTransactionValidator = accountTransactionValidator;
            _cardChargeValidator = cardChargeValidator;
        }

        public UploadResult UploadCardAccountFile(byte[] bytes)
        {
            // TODO use appropriate reader to read the file
            // TODO use appropriate validator to validate file entitites
            // TODO if all entitites are valid call appropriate persister to persist entitites to database

            var items = _xmlReader.ReadFile<CardAccountFileEntity>(bytes);

            var validationResult = _cardAccountValidator.ValidateCardAccountList(items);

            if (validationResult.IsValid)
            {

            }

            throw new System.NotImplementedException();
        }

        public UploadResult UploadAccountTransactionFile(byte[] bytes)
        {
            throw new System.NotImplementedException();
        }

        public UploadResult UploadCardChargeFile(byte[] bytes)
        {
            throw new System.NotImplementedException();
        }
    }
}
