﻿using System;
using FileHelpers;

namespace CardAccount.Service.Entity.File
{
    [FixedLengthRecord(FixedMode.ExactLength)]
    public class AccountTransactionFileEntity : IFileEntity
    {
        [FieldFixedLength(10)]
        public string AccountNumber { get; set; }

        [FieldFixedLength(8)]
        [FieldConverter(ConverterKind.Date, "yyyyMMdd")]
        public DateTime? Date { get; set; }

        [FieldFixedLength(10)]
        public decimal? Amount { get; set; }

        [FieldFixedLength(2)]
        [FieldTrim(TrimMode.Right)]
        public string TransactionType { get; set; }
    }
}
