﻿namespace CardAccount.Service.Entity.File
{
    public interface IFileEntity
    {
       
    }
}
