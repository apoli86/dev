﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace CardAccount.Service.Entity.File
{
    [XmlRoot("conto")]
    public class CardAccountFileEntity : IFileEntity
    {
        [XmlAttribute("Numero")]
        public string AccountNumber { get; set; }

        [XmlElement("carta")]
        public List<CardReference> Cards { get; set; }
    }

    public class CardFileEntity
    {
        [XmlAttribute("Numero")]
        public string Number { get; set; }
    }
}
