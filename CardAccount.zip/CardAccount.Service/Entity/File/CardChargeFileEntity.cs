﻿using System;
using FileHelpers;

namespace CardAccount.Service.Entity.File
{
    [DelimitedRecord(",")]
    [IgnoreFirst(1)]
    public class CardChargeFileEntity : IFileEntity
    {
        public string Number { get; set; }
        [FieldConverter(ConverterKind.DateMultiFormat, "d/MM/yyyy", "dd/MM/yyyy")]
        public DateTime? Date { get; set; }
        public decimal? Amount { get; set; }
    }
}
