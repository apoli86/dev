﻿namespace CardAccount.Service.Entity
{
    public enum TraceType
    {
        Fixed,
        Csv
    }
}