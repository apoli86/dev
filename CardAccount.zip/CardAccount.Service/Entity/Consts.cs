﻿namespace CardAccount.Service.Entity
{
    public static class Consts
    {
        public static class TransactionType
        {
            public const string CR = "CR";
            public const string DR = "DR";
        }
    }
}