﻿
using CardAccount.Model;

namespace CardAccount.Dal.Writer.Interface
{
    public interface ICardWriter
    {
        Card AddCard();
    }
}