﻿
namespace CardAccount.Dal.Writer.Interface
{
    public interface ICardChangeWriter
    {
        Model.CardCharge AddCardCharge();
    }
}