﻿namespace CardAccount.Dal.Writer.Interface
{
    public interface ICardAccountWriter
    {
        Model.CardAccount AddCardAccount();
    }
}