﻿using CardAccount.Model;

namespace CardAccount.Dal.Writer.Interface
{
    public interface IAccountMonthlyMatchWriter
    {
        AccountMonthlyMatch AddAccountMonthlyMatch();
    }
}