﻿using System;
using CardAccount.Dal.Writer.Interface;

namespace CardAccount.Dal.Writer.Implementation
{
    public class CardAccountWriter : ICardAccountWriter
    {
        public Model.CardAccount AddCardAccount()
        {
            throw new NotImplementedException();
        }
    }
}