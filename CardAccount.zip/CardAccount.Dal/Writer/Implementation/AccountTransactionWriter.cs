﻿using System;
using CardAccount.Dal.Writer.Interface;
using CardAccount.Model;

namespace CardAccount.Dal.Writer.Implementation
{
    public class AccountTransactionWriter : IAccountTransactionWriter
    {
        public AccountTransaction AddAccountTransaction()
        {
            throw new NotImplementedException();
        }
    }
}