﻿
using CardAccount.Dal.Writer.Interface;
using CardAccount.Model;

namespace CardAccount.Dal.Writer.Implementation
{
    public class CardChargeWriter : ICardChangeWriter
    {
        public CardCharge AddCardCharge()
        {
            throw new System.NotImplementedException();
        }
    }
}