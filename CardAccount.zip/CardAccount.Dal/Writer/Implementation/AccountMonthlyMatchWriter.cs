﻿using System;
using CardAccount.Dal.Writer.Interface;
using CardAccount.Model;

namespace CardAccount.Dal.Writer.Implementation
{
    public class AccountMonthlyMatchWriter : IAccountMonthlyMatchWriter
    {
        public AccountMonthlyMatch AddAccountMonthlyMatch()
        {
            throw new NotImplementedException();
        }
    }
}