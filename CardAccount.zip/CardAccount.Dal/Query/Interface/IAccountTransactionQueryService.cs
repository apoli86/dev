﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAccount.Dal.Query.Interface
{
    interface IAccountTransactionQueryService
    {
        //TODO method GetAccountTransactions and returns all entites with DTO
    }
}
