﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAccount.Dal.Query.Interface
{
    interface ICardAccountQueryService
    {
        //TODO method GeCardAccounts and returns all entites with DTO
    }
}
