﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAccount.Dal.Query.Interface
{
    interface ICardChargeQueryService
    {
        //TODO method GetCardCharges and returns all entites with DTO
    }
}
