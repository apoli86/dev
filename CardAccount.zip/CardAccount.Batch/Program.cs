﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAccount.Batch
{
    class Program
    {
        static void Main(string[] args)
        {
            //TODO read parameter from command line for year and month to process
            //TODO call AccountMonthlyMatchOrchestrator
        }
    }
}
