# PGPMiddleware 1.0
PGPMiddleware is a simple tool which helps encrypting & signing or veryfing & decrypting files using PGP. *This tool is PoC and should not be used in production*.

## Requirements
- GPG for creating public and private keypairs
- GPG public and private keyrings (sample keyrings provided in gpg directory)
- JDK >=8 for building with Gradle
- JRE >=8 for running pgpmiddleware.jar

## Getting started

### Overview
The tool is based on [BouncyGPG](https://github.com/neuhalje/bouncy-gpg/#readme)

The compiled version of the tool consists of:
- pgpmiddleware.jar: the jar of the tool built with gradle
- config.properties: the configuration file of the tool 
- gpg folder: a folder with sample public & private keyrings (2 keypairs for john.smith@companya.com and alan.turing@companyb.com users)

```
.
|-- lib
	|-- src
	|-- build
		|-- libs
			|-- pgpmiddleware.jar
			|-- config.properties
			|-- gpg
				|-- pubring.gpg
				|-- trustdb.gpg
|-- gradle
	|-- wrapper
		|-- gradle-wrapper.jar
		|-- gradle-wrapper.properties
|-- gradlew
|-- gradlew.bat
|-- README.md
```

### Create your keypairs
Please refer to GPG documentation. Please note that this tool does not support private key password so **private key must be created without password**.

### Extract keyrings
**Extract public keyring**

`gpg --export -a > pubring.gpg` 

**Extract private keyring**

`gpg --export-secret-keys -a > trustdb.gpg` 

**Copy the keyrings inside gpg directory**

### Update config.properties

```
PublicKeyRing=gpg\\pubring.gpg
PrivateKeyRing=gpg\\trustdb.gpg
SignWith=john.smith@companya.com
```

### Encrypt & sign a file

```
java -Dsun.stdout.encoding=UTF-8 -Dsun.stderr.encoding=UTF-8 -jar pgpmiddleware.jar encrypt -r alan.turing@companyb.com -i sample.jpg -o sample.jpg.encrypted
```

```
11:22:14.605 [main] INFO  b.p.c.ConfigurationReader - Loading configuration from file (config.properties)
11:22:14.620 [main] INFO  b.p.middleware.PgpMiddlewareEncrypt - Reading file (sample.jpg) to be encrypted with public key of (alan.turing@companyb.com) and signed with private key of (john.smith@companya.com)
11:22:14.620 [main] INFO  b.p.middleware.KeyringConfigBuilder - Creating Keyrings Repository using public keyring(gpg\pubring.gpg) and private keyring(gpg\trustdb.gpg)
11:22:15.982 [main] INFO  b.p.middleware.PgpMiddlewareEncrypt - Writing encrypted data into output file (sample.jpg.encrypted)
```

### Verify and decrypt a file

```
java -Dsun.stdout.encoding=UTF-8 -Dsun.stderr.encoding=UTF-8 -jar pgpmiddleware.jar encrypt -r alan.turing@companyb.com -i sample.jpg -o sample.jpg.encrypted
```

```
11:23:16.466 [main] INFO  b.p.c.ConfigurationReader - Loading configuration from file (config.properties)
11:23:16.480 [main] INFO  b.p.middleware.KeyringConfigBuilder - Creating Keyrings Repository using public keyring(gpg\pubring.gpg) and private keyring(gpg\trustdb.gpg)
11:23:16.482 [main] INFO  b.p.middleware.PgpMiddlewareDecrypt - Reading file (sample.jpg.encrypted) to be verified and decrypted
11:23:16.732 [main] DEBUG n.n.p.c.b.openpgp.keys.PGPUtilities - Finding secret key with key ID '0xbbd8917d366acf9'
11:23:17.435 [main] DEBUG n.n.p.c.b.o.v.RequireAnySignatureValidationStrategy - Successfully validated signature with key 0xb5afecfc601c4619
11:23:17.436 [main] DEBUG n.n.p.c.b.o.v.RequireAnySignatureValidationStrategy - Signature verification success
11:23:17.443 [main] INFO  b.p.middleware.PgpMiddlewareDecrypt - Writing decrypted data into file (sample.jpg.decrypted)
```

## How to build
Please note that gradlew is included inside *gradle* directory.

```
gradlew build
```