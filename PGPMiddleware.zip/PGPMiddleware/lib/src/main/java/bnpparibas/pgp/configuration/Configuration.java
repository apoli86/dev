package bnpparibas.pgp.configuration;

import org.apache.commons.lang3.Validate;

public class Configuration {
	private String publicKeyring;
	private String privateKeyring;
	private String signWith;
	
	public Configuration(String publicKeyring, String privateKeyring, String signWith) {
		Validate.notBlank(publicKeyring);
		Validate.notBlank(privateKeyring);
		Validate.notBlank(signWith);		
		
		this.publicKeyring = publicKeyring;
		this.privateKeyring = privateKeyring;
		this.signWith = signWith;
	}
	
	public String getPublicKeyring() {
		return publicKeyring;
	}
	public String getPrivateKeyring() {
		return privateKeyring;
	}
	public String getSignWith() {
		return signWith;
	}

}
