package bnpparibas.pgp.middleware;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.security.InvalidParameterException;
import java.util.concurrent.Callable;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.Validate;
import org.bouncycastle.util.io.Streams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.inject.Inject;

import bnpparibas.pgp.configuration.Configuration;
import bnpparibas.pgp.configuration.ConfigurationReader;
import bnpparibas.pgp.validator.EmailValidator;
import name.neuhalfen.projects.crypto.bouncycastle.openpgp.BouncyGPG;
import name.neuhalfen.projects.crypto.bouncycastle.openpgp.keys.keyrings.KeyringConfig;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

@Command(name = "encrypt", mixinStandardHelpOptions = true, version = "PgpMiddleware 1.0", description = "Encrypt & Sign a file")
public class PgpMiddlewareEncrypt implements Callable<Integer> {
	private static Logger logger = LoggerFactory.getLogger(PgpMiddlewareEncrypt.class);
	
	private final ConfigurationReader configurationReader;
	private final KeyringConfigBuilder keyringConfigBuilder;
	private final EmailValidator emailValidator;
	
	@Option(names = { "-i", "--inputfile" }, description = "file to be encrypted", required = true)
	private File file;

	@Option(names = { "-r", "--recipient" }, description = "recipient email", required = true)
	private String recipientEmail;
	
	@Option(names = { "-o", "--outputfile" }, description = "output file", required = true)
	private String outputFile;

	@Inject
	public PgpMiddlewareEncrypt(ConfigurationReader configurationReader, KeyringConfigBuilder keyringConfigBuilder, EmailValidator emailValidator) {
		Validate.notNull(configurationReader);
		Validate.notNull(keyringConfigBuilder);
		Validate.notNull(emailValidator);
		
		this.configurationReader = configurationReader;
		this.keyringConfigBuilder = keyringConfigBuilder;
		this.emailValidator = emailValidator;
	}

	@Override
	public Integer call() throws Exception {
		try {
			Configuration config = configurationReader.read();
			logger.info("Reading file (" + file.getAbsolutePath() + ") to be encrypted with public key of (" + recipientEmail + ") and signed with private key of ("+ config.getSignWith() +")");
			
			KeyringConfig keyringConfig = keyringConfigBuilder.Build(config.getPublicKeyring(), config.getPrivateKeyring());
			
			String recipientEmailTrimmed = recipientEmail.trim();
			if (!emailValidator.Validate(recipientEmailTrimmed))
			{
				throw new InvalidParameterException("Recipient Email (" + recipientEmail + ") must be a valid e-mail address");
			}
			
			ByteArrayOutputStream encryptedOutputStream = new ByteArrayOutputStream();
			ByteArrayInputStream is = new ByteArrayInputStream(Files.readAllBytes(file.toPath()));

			try (BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(encryptedOutputStream);

					final OutputStream encryptedStream = BouncyGPG.encryptToStream()
															   .withConfig(keyringConfig)
															   .withStrongAlgorithms()
															   .toRecipients(recipientEmailTrimmed)
															   .andSignWith(config.getSignWith())
															   .binaryOutput().andWriteTo(bufferedOutputStream);

			) {
				Streams.pipeAll(is, encryptedStream);
			}

			encryptedOutputStream.close();
			byte[] encryptedOutputBytes = encryptedOutputStream.toByteArray();
			
			logger.info("Writing encrypted data into output file (" + outputFile + ")");
			OutputStream outStream = new FileOutputStream(outputFile.trim());
			outStream.write(encryptedOutputBytes);
			IOUtils.closeQuietly(outStream);
			
			//Files.write(Path.of(outputFile.trim()), encryptedOutputBytes, StandardOpenOption.CREATE);
		} catch (Exception ex) {
			logger.error("Error while encrypting", ex);
			
			return -1;
		}

		return 0;
	}

}
