package bnpparibas.pgp.validator;

import java.util.regex.Pattern;

public class EmailValidator {
	private final Pattern emailRegex;
	
	public EmailValidator()
	{
		String owaspEmailAddressRegex = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";
		emailRegex = Pattern.compile(owaspEmailAddressRegex);
	}
	
	public boolean Validate(String emailAddress)
	{
		org.apache.commons.lang3.Validate.notBlank(emailAddress);
		
		return emailRegex.matcher(emailAddress).matches();
	}
}
