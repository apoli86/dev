package bnpparibas.pgp.middleware;

import java.io.File;
import java.io.FileNotFoundException;

import org.apache.commons.lang3.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import name.neuhalfen.projects.crypto.bouncycastle.openpgp.keys.callbacks.KeyringConfigCallbacks;
import name.neuhalfen.projects.crypto.bouncycastle.openpgp.keys.keyrings.KeyringConfig;
import name.neuhalfen.projects.crypto.bouncycastle.openpgp.keys.keyrings.KeyringConfigs;

public class KeyringConfigBuilder {
	private static Logger logger = LoggerFactory.getLogger(KeyringConfigBuilder.class);

	@SuppressWarnings("deprecation")
	public KeyringConfig Build(String publicKeyringPath, String privateKeyringPath) throws Exception
	{
		Validate.notBlank(publicKeyringPath);
		Validate.notBlank(privateKeyringPath);
		
		File publicKeyring = new File(publicKeyringPath);
		File privateKeyring = new File(privateKeyringPath);
		
		logger.info("Creating Keyrings Repository using public keyring(" + publicKeyring.getAbsolutePath() + ") and private keyring(" + privateKeyring.getAbsolutePath() + ")");
		
		if (!publicKeyring.exists())
		{
			throw new FileNotFoundException("Public keyring (" + publicKeyring.getAbsolutePath() + ") not found");
		}
		if (!privateKeyring.exists())
		{
			throw new FileNotFoundException("Private keyring (" + privateKeyring.getAbsolutePath() + ") not found");
		}
		
		return KeyringConfigs.withKeyRingsFromFiles(publicKeyring, privateKeyring, KeyringConfigCallbacks.withUnprotectedKeys());
		
		/*InMemoryKeyring keyringConfig = KeyringConfigs.forGpgExportedKeys(KeyringConfigCallbacks.withUnprotectedKeys());
		
		String privateKeyringText = Files.readString(Path.of(privateKeyring.getAbsolutePath()));
		String publicKeyringText = Files.readString(Path.of(publicKeyring.getAbsolutePath()));
		
		keyringConfig.addSecretKey(privateKeyringText.getBytes("US-ASCII"));
		keyringConfig.addPublicKey(publicKeyringText.getBytes("US-ASCII"));
		
		return keyringConfig;*/	
	}
}
