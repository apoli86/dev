package bnpparibas.pgp.guice;

import com.google.inject.AbstractModule;

import bnpparibas.pgp.middleware.KeyringConfigBuilder;
import bnpparibas.pgp.middleware.PgpMiddlewareDecrypt;
import bnpparibas.pgp.middleware.PgpMiddlewareEncrypt;

public class GuiceModule extends AbstractModule {

	@Override
	protected void configure()
	{
		requestStaticInjection(KeyringConfigBuilder.class);
		requestStaticInjection(PgpMiddlewareDecrypt.class);
		requestStaticInjection(PgpMiddlewareEncrypt.class);
	}
}
