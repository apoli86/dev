package bnpparibas.pgp.middleware;

import picocli.CommandLine;
import picocli.CommandLine.Command;
import picocli.CommandLine.Model.CommandSpec;
import picocli.CommandLine.Spec;

@Command(name = "ppgmiddleware",
subcommands = { PgpMiddlewareDecrypt.class, PgpMiddlewareEncrypt.class, CommandLine.HelpCommand.class }, 
description = "Encrypt & Sign or Verify & Decrypt a file", version = "PgpMiddleware 1.0")
public class PGPMiddleware {
	@Spec CommandSpec spec;
}
