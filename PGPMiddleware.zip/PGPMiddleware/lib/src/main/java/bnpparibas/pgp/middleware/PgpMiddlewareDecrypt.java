package bnpparibas.pgp.middleware;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.concurrent.Callable;

import org.apache.commons.lang3.Validate;
import org.bouncycastle.util.io.Streams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.inject.Inject;

import bnpparibas.pgp.configuration.Configuration;
import bnpparibas.pgp.configuration.ConfigurationReader;
import name.neuhalfen.projects.crypto.bouncycastle.openpgp.BouncyGPG;
import name.neuhalfen.projects.crypto.bouncycastle.openpgp.keys.keyrings.KeyringConfig;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

@Command(name = "decrypt", mixinStandardHelpOptions = true, version = "PgpMiddleware 1.0", description = "Verify & Decrypt a file")
public class PgpMiddlewareDecrypt implements Callable<Integer> {
	private static Logger logger = LoggerFactory.getLogger(PgpMiddlewareDecrypt.class);
	
	private final ConfigurationReader configurationReader;
	private final KeyringConfigBuilder keyringConfigBuilder;
	
	@Option(names = { "-i", "--inputfile" }, description = "file to be decrypted", required = true)
	private File file;
	
	@Option(names = { "-o", "--outputfile" }, description = "output file", required = true)
	private String outputFile;
	
	@Inject
	public PgpMiddlewareDecrypt(ConfigurationReader configurationReader, KeyringConfigBuilder keyringConfigBuilder) {
		Validate.notNull(configurationReader);
		Validate.notNull(keyringConfigBuilder);

		this.configurationReader = configurationReader;
		this.keyringConfigBuilder = keyringConfigBuilder;
	}

	@Override
	public Integer call() throws Exception {
		try {
			Configuration config = configurationReader.read();
			KeyringConfig keyringConfig = keyringConfigBuilder.Build(config.getPublicKeyring(), config.getPrivateKeyring());

			ByteArrayOutputStream result = new ByteArrayOutputStream();

			logger.info("Reading file (" + file.getAbsolutePath() + ") to be verified and decrypted");
			
			ByteArrayInputStream encryptedStream = new ByteArrayInputStream(Files.readAllBytes(Path.of(file.getAbsolutePath())));

			try (BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(result);

					final InputStream decryptedStream = BouncyGPG
			                .decryptAndVerifyStream()
			                .withConfig(keyringConfig)
			                .andValidateSomeoneSigned()
			                .fromEncryptedInputStream(encryptedStream)

			) {
				Streams.pipeAll(decryptedStream, result);
			}

			result.close();
			byte[] outputFileBytes = result.toByteArray();

			logger.info("Writing decrypted data into file (" + outputFile + ")");
			Files.write(Path.of(outputFile.trim()), outputFileBytes, StandardOpenOption.CREATE);
		} catch (Exception ex) {
			logger.error("Error while decrypting", ex);
			return -1;
		}

		return 0;
	}

}
