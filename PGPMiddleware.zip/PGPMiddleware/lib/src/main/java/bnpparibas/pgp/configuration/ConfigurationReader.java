package bnpparibas.pgp.configuration;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.security.InvalidParameterException;
import java.util.Properties;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Strings;
import com.google.inject.Inject;

import bnpparibas.pgp.validator.EmailValidator;

public class ConfigurationReader {
	private static Logger logger = LoggerFactory.getLogger(ConfigurationReader.class);
	private final EmailValidator emailValidator;
	
	@Inject
	public ConfigurationReader(EmailValidator emailValidator)
	{
		Validate.notNull(emailValidator);
		this.emailValidator = emailValidator;
	}
	
	public Configuration read() throws Exception {
		try {
			File configurationFile = new File("config.properties");
			
			logger.info("Loading configuration from file (" + configurationFile.getAbsolutePath() + ")");

			if (!configurationFile.exists())
			{
				throw new FileNotFoundException("Configuration file not found: " + configurationFile.getAbsolutePath());
			}
			
			try(ByteArrayInputStream is = new ByteArrayInputStream(IOUtils.toByteArray(configurationFile.toURI())))
			{
				Properties prop = new Properties();
				prop.load(is);
				
				String publicKeyRing = prop.getProperty("PublicKeyRing");
				String privateKeyRing = prop.getProperty("PrivateKeyRing");
				String signWith = prop.getProperty("SignWith");

				if (Strings.isNullOrEmpty(publicKeyRing))
				{
					throw new InvalidParameterException("PublicKeyRing cannot be null or empty");
				}
				if (Strings.isNullOrEmpty(privateKeyRing))
				{
					throw new InvalidParameterException("PrivateKeyRing cannot be null or empty");
				}
				if (Strings.isNullOrEmpty(signWith))
				{
					throw new InvalidParameterException("SignWith cannot be null or empty");
				}
				if (!emailValidator.Validate(signWith.trim()))
				{
					throw new InvalidParameterException("SignWith (" + signWith + ") must be a valid e-mail address");
				}
				
				Configuration configuration = new Configuration(publicKeyRing.trim(), privateKeyRing.trim(), signWith.trim());

				return configuration;				
			}
		} catch (Exception e) {
			throw e;
		}

	}

}
